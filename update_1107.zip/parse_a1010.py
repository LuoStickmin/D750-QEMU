import sys, struct

d = open(sys.argv[1], "rb").read()

print("--- first 0x80 as BE/LE words ---")
for off in range(0, 0x80, 4):
    be = struct.unpack_from(">I", d, off)[0]
    le = struct.unpack_from("<I", d, off)[0]
    print("0x%03X  BE=0x%08X  LE=0x%08X" % (off, be, le))

print("\n--- BE values in 0x40..0x400 that look like offsets ---")
for off in range(0x40, min(len(d), 0x400), 4):
    v = struct.unpack_from(">I", d, off)[0]
    if 0 < v < len(d):
        print("0x%03X -> 0x%X" % (off, v))
