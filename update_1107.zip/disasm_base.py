import sys
from capstone import *

d = open(sys.argv[1], "rb").read()
base = int(sys.argv[2], 0)
off = int(sys.argv[3], 0)
n = int(sys.argv[4]) if len(sys.argv) > 4 else 40

for mode, name in [(CS_MODE_ARM, "ARM"), (CS_MODE_THUMB, "THUMB")]:
    print("\n--- %s ---" % name)
    md = Cs(CS_ARCH_ARM, mode)
    for ins in list(md.disasm(d[off:off+0x200], base + off))[:n]:
        print("0x%08X  %-8s %s" % (ins.address, ins.mnemonic, ins.op_str))
