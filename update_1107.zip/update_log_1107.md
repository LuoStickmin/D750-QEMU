# Update Log · 2025-11-07 · D750-QEMU M1：启动链打通与 a1010 入口定位

> 本轮目标：把 D750-QEMU 从 **M0（b1010 装入 `0x90000000` 能跑）** 推进到 **M1（接上真正启动链、明确 a1010 入口／加载基址／指令集）**。
> 结论：**启动链已完全打通、a1010 真实加载基址与入口函数已定位并反汇编确认。** 剩下只差 QEMU 侧按本文改动后实跑一次。

---

## TL;DR

| 项 | 结论 | 状态 |
|---|---|---|
| b1010 启动桩 `0x9025D700` | 逐条走通，`bx ip → 0x1002CB8C` | ✅ 实测 |
| a1010 加载基址 | **`0x10018000`**（不是 `0x10000000`） | ✅ 实测 |
| a1010 入口 | 文件偏移 **`0x14B8C`**（Thumb 函数，已完整反汇编） | ✅ 实测 |
| a1010 指令集 | **Thumb-2，小端** | ✅ 实测 |
| `bx` 的 Thumb 位 | 目标 bit0=0（ARM），但代码是 Thumb → **必须用 `0x1002CB8D`** | ✅ 实测 |
| config 槽 `0x100F48C0/C4/C8` | 在 a1010 模块之外（下一模块／整片 flash） | ✅ 实测 |
| QEMU 里"0 MMIO"疑似真凶 | 未映射 flash 读 `0xFF` 会让 `blxne` 跳到 `0xFFFFFFFF` 跑飞 | ⚠️ 高可信，待实机确认 |

关键踩坑教训：**之前所有反汇编只看了 `ARM-BE / THUMB-BE / THUMB-LE`，漏了 `ARM-LE`；而且一开始用错了加载基址，导致把代码区当数据段。** 定位基址后，入口函数一次连续解完、无一处乱码。

---

## 1. b1010 启动桩 `0x9025D700`（逐条实测 trace）

b1010 装于 `0x90000000`，桩位于 `0x9025D700`（= 文件偏移 `0x25D700`）。下面是**真实固件**跑出的单步 trace（见 `stub_trace.py`）：

```asm
0x9025D700  ldr  r0, [pc]      ; 字面量@0x25D7E8 = 0x902A2EA0（b1010 内部 BSS 指针）
0x9025D704  ldr  r0, [r0]      ; = 0
0x9025D708  cmp  r0, #0
0x9025D70C  blxne r0           ; 非 0 才调用（此处为 0，跳过）
0x9025D710  ldr  r0, [pc]      ; 字面量 = 0x100F48C0
0x9025D714  ldr  r0, [r0]      ; = *(0x100F48C0)
0x9025D718  mov  r1, #0
0x9025D71C  bl   0x9025DA40    ; 本地 init（见 §1.1）
0x9025D720  mrc  p15,0,r0,c1,c0,0   ; 读 SCTLR
0x9025D724  orr  r0, r0, #2    ; 打开对齐检查 (SCTLR.A)
0x9025D728  mcr  p15,0,r0,c1,c0,0   ; 写回
0x9025D72C  ldr  r0, [pc]      ; 字面量 = 0x100F48C4
0x9025D730  ldr  r0, [r0]      ; r0 = *(0x100F48C4)
0x9025D734  ldr  r1, [pc]      ; 字面量 = 0x100F48C8
0x9025D738  ldr  r1, [r1]      ; r1 = *(0x100F48C8)
0x9025D73C  mov  r2, #2
0x9025D740  mov  r3, #0
0x9025D744  mov  r4, #1
0x9025D748  ldr  r12, [pc]     ; 字面量@0x25D7F8 = 0x1002CB8C
0x9025D74C  mov  lr, #0x9025D754   ; 返回地址
0x9025D750  bx   r12           ; → 0x1002CB8C
```

要点：
- 桩是**带参数调用** a1010，而非纯跳转：
  `func( *(0x100F48C4), *(0x100F48C8), 2, 0, 1 )`，返回地址 `0x9025D754`。
  即 `0x1002CB8C` 是 a1010 里一个**会返回的初始化函数**。
- **纠正一条旧记录**：`0x25D7E8` 处的字面量其实是 `0x902A2EA0`（b1010 内部 BSS 指针），**不是** `0x100F48C8`（此前手算有误）。真正被读的 config 槽是 `0x100F48C0 / 0x100F48C4 / 0x100F48C8` 三处。

### 1.1 关于 `bl 0x9025DA40`（init）
实测时用 `--skip-init` 跨过它（不影响后续 `bx` 目标）。它是 b1010 内部的本地初始化，和 a1010 无关，后续再单独拆。

---

## 2. a1010 加载基址 = `0x10018000`（本轮最大突破）

`bx` 目标固定为 `0x1002CB8C`。用 `stub_trace.py --find-base` 扫描页对齐基址，找哪个 base 能让该目标精确落在**函数序言**上，唯一命中：

```
★ base=0x10018000  foff=0x14B8C  [10 B5 14 20 F9 F7]  Thumb push {...,lr}
```

即：
```
0x1002CB8C − 0x10018000 = 0x14B8C   ← 落在 a1010 代码区 0x14000~0x20000
```

对照几个错误假设：

| base | bx 目标映射到 file | 那里是什么 | 结论 |
|---|---|---|---|
| `0x10000000` | `0x2CB8C` | 数据表（每 4 字节低半字恒 `0x0020`，ARM/Thumb 解都是垃圾） | ❌ |
| `0x10000040` | `0x2CB4C` | 另一段 Thumb 代码，但被当 ARM 进 | ❌ |
| **`0x10018000`** | **`0x14B8C`** | **干净 Thumb 函数 `push{r4,lr}; movs r0,#0x14; bl…`** | ✅ |

> 旁证：a1010 的 **157 项大端偏移表在 `0x40–0x2B3`**，表项入口全指 `0x14009 / 0x14063 / …`（`0x14xxx` 代码区）；`0x2CBxx` 属于数据段。基址 0x10018000 才让 bx 目标落回代码。

---

## 3. a1010 入口函数 `file 0x14B8C`（完整反汇编，Thumb-2）

```asm
0x14B8C: B510        push {r4, lr}
0x14B8E: 2014        movs r0, #0x14
0x14B90: F7F9 FFDF   bl   0x0EB52
0x14B94: 2204        movs r2, #4
0x14B96: 2100        movs r1, #0
0x14B98: 200F        movs r0, #0xF
0x14B9A: F7F8 F8DD   bl   0x0CD58        ; 初始化单元 #0
0x14B9E: 2204        movs r2, #4
0x14BA0: 2101        movs r1, #1
0x14BA2: 200F        movs r0, #0xF
0x14BA4: F7F8 F8D8   bl   0x0CD58        ; 初始化单元 #1
0x14BA8: 2204        movs r2, #4
0x14BAA: 2102        movs r1, #2
0x14BAC: 200F        movs r0, #0xF
0x14BAE: F7F8 FA47   bl   0x0D040        ; 初始化单元 #2
0x14BB2: 2201        movs r2, #1
0x14BB4: 2140        movs r1, #0x40
0x14BB6: 2014        movs r0, #0x14
0x14BB8: F7F7 FE32   bl   0x0C820
0x14BBC: 2014        movs r0, #0x14
0x14BBE: F7F9 FEF0   bl   0x0E9A2
0x14BC2: 4996        ldr   r1, [pc,#0x258]  ; = [0x14E1C]
0x14BC4: 4894        ldr   r0, [pc,#0x250]  ; = [0x14E18]
0x14BC6: 6008        str   r0, [r1, #0]
0x14BC8: E8BD 4010   pop.w {r4, lr}          ; 返回
```

- **整段连续解码、无一处乱码** —— 这是"基址/入口/Thumb"三者都对上的最硬证据。
- 语义：一个**配置初始化函数**——以 `r1=0/1/2、r0=0xF（寄存器基）、r2=4（大小）` 初始化三个单元，再做两次 `r0=0x14` 的收尾调用，最后把 `[0x14E18]` 的值写入 `[0x14E1C]` 返回。
- 所有 `bl` 目标（`0x0EB52 / 0x0CD58 / 0x0D040 / 0x0C820 / 0x0E9A2`）均落在 a1010 内部低地址 helper 区，自洽。

---

## 4. 必须修的「Thumb 位」

- `bx ip` 目标 `0x1002CB8C` 的 **bit0 = 0 → CPU 进 ARM 态**；
- 但 `file 0x14B8C` 是 **Thumb 代码**。
- ⇒ 必须让 bx 进 Thumb：目标应为 **`0x1002CB8D`**（bit0=1）。

修法二选一：
- **(A) 改固件**：把 b1010 文件偏移 `0x25D7F8` 的字面量 `0x1002CB8C → 0x1002CB8D`，重打包（注意包 CRC / `SHA1(body||K8)` 完整性）。
- **(B) 改 QEMU**：不改固件，在 PC 命中 `0x9025D750 (bx ip)` 时断点拦截，把 `ip |= 1` 后继续。

> 此前把这条列为"E3 假设"，现在被真实字节正面证实——不是可选项，是必须。

---

## 5. config 槽 `0x100F48C0 / C4 / C8` 在 a1010 之外

```
0x100F48C0 − 0x10018000 = 0xDC8C0
0x100F48C4 − 0x10018000 = 0xDC8C4
0x100F48C8 − 0x10018000 = 0xDC8C8
a1010 大小 = 0xC0000  → 以上均超出 a1010 末端，属"下一模块"或整片 flash 的配置区
```

- 无整片 flash 时，桩这三处读 0，走 **degenerate"无回调"路径**（`func(0,0,2,0,1)`），硬件没被真正初始化 → 自然看不到 MMIO。
- **要做的事**：用**下一模块 / 整片 flash** 把这三槽填成真实值，让桩走真回调。

---

## 6. 「0 MMIO」的隐藏嫌疑（高可信，待实机确认）

在单步模拟里发现：若 **QEMU 未映射内存默认返回 `0xFF`**，则：
```
*(0x100F48C8) = 0xFFFFFFFF → blxne r0 → 跳到 0xFFFFFFFF（末位=1 还进 Thumb）→ 立刻跑飞
```
这很可能就是 M1 阶段"0 MMIO"的直接原因（不是设备没建模，而是启动桩被带沟里）。
- 对策：QEMU 未映射读**置 0**；或提供真实整片 flash。

---

## 7. 本轮工具（已实现并测通）

| 文件 | 作用 |
|---|---|
| `stub_trace.py` | **零依赖**纯 Python 启动桩单步模拟器（ARM 子集解释器）。`--find-base` 定基址、`--skip-init` 跨 init、`--flash` 灌整片 flash、`--unmapped` 设未映射读值、到达 bx 后自动 hexdump 入口字节。 |
| `d750_m1_analyze.py` | 静态分析四件套：`stub`（字面量/分支追踪）、`table`（157 项表端序判定）、`disasm`（ARM/Thumb × LE/BE 四模式反汇编）、`refs`（引用搜索）、`verdict`。 |
| `d750_m1_qemu_snippet.c` | QEMU 集成片段：复位进 `0x9025D700`、a1010 映射 `0x10018000`、bx 位修复、config 窗、trace 指引。 |

> 开发过程中在模拟器里抓到并修正 3 个 bug：① LDR 字面量漏 `PC+8`；② `BX/BLX`（`0x012FFF1x`）bit27-26=00 会被数据处理分支先截胡，需前置判定；③ 掩码应为 `0x0FFFFFF0`。修完用合成指令 + 真实固件双向验证。

---

## 8. 复现命令

```powershell
# 1) 定基址（得分点：base=0x10018000, foff=0x14B8C）
python stub_trace.py --find-base --a1010 D750_0115.dec.modules\a1010_011100.bin

# 2) 按真基址单步 + dump 入口
python stub_trace.py --b1010 D750_0115.dec.modules\b1010_115a.bin `
                     --a1010 D750_0115.dec.modules\a1010_011100.bin --a1010-base 0x10018000

# 3) 双模式反汇编入口
python d750_m1_analyze.py disasm D750_0115.dec.modules\a1010_011100.bin 0x14B8C --base 0x10018000 --n 24
```

---

## 9. QEMU 侧改动清单（M1 落地）

1. **a1010 映射到 `0x10018000`**（关键）。
2. 复位 **PC=`0x9025D700`**，SVC 态，给 SP；不再手动调 `0x9027D52C`。
3. **bx 位修复**：改 `0x25D7F8` 字面量为 `0x1002CB8D`，或 QEMU 拦 `0x9025D750` 做 `ip|=1`。
4. **config 槽**：用下一模块/整片 flash 填 `0x100F48C0/C4/C8`；未映射读置 0。
5. 观察：`-d in_asm,exec,cpu,int -D qemu.log`，确认 PC 能稳进 `0x1002CB8D` 并在 a1010 内连续执行。

---

## 10. 待办 / 需要讨论

- [ ] 按 §9 改 QEMU 实跑，出 `qemu.log`：确认真正进入 `0x1002CB8D`（Thumb）并在 a1010 连续执行 → **即 M1 达成**。
- [ ] 拆 `0x9025DA40`（b1010 init）与入口函数调用的 helper（`0x0EB52 / 0x0CD58 / 0x0D040 / 0x0C820 / 0x0E9A2`）。
- [ ] 定位 a1010 的 flash 装载偏移（= `0x18000`？）与**下一模块**（config 槽所在），拿到整片 flash / 模块偏移表。
- [ ] 第一条 a1010 之后的 MMIO 访问地址（M1 验收点）→ 据此进入 M2 外设建模。

---

*附：本文所有地址/字节均来自D750_0115.bin实测，未作假设。若与你本地结果有出入，请以 `stub_trace.py --find-base` 输出为准并在 issue 附上。*

---

# Update Log · 2025-11-07 · D750-QEMU M1: Boot Chain Resolved & a1010 Entry Located (English)

> Goal: advance D750-QEMU from **M0 (b1010 loads at `0x90000000` and runs)** to **M1 (hook up the real boot chain; pin down a1010's entry / load base / instruction set)**.
> Result: **the boot chain is fully resolved, and a1010's real load base and entry function are located and disassembled.** What remains is to apply the QEMU-side changes below and do one real run.

---

## TL;DR

| Item | Result | Status |
|---|---|---|
| b1010 boot stub `0x9025D700` | stepped through line by line, `bx ip → 0x1002CB8C` | ✅ measured |
| a1010 load base | **`0x10018000`** (not `0x10000000`) | ✅ measured |
| a1010 entry | file offset **`0x14B8C`** (Thumb function, fully disassembled) | ✅ measured |
| a1010 ISA | **Thumb-2, little-endian** | ✅ measured |
| `bx` Thumb bit | target bit0=0 (ARM), but code is Thumb → **must use `0x1002CB8D`** | ✅ measured |
| config slots `0x100F48C0/C4/C8` | outside the a1010 module (next module / full flash) | ✅ measured |
| Suspected real cause of "0 MMIO" | unmapped flash reads `0xFF` → `blxne` jumps to `0xFFFFFFFF` and dies | ⚠️ high confidence, to be confirmed on hardware |

Key lesson: **all previous disassembly only looked at `ARM-BE / THUMB-BE / THUMB-LE` and missed `ARM-LE`; furthermore we used the wrong load base, treating code as a data segment.** After locating the base, the entry function decodes continuously with zero garbage.

---

## 1. b1010 boot stub `0x9025D700` (measured single-step trace)

b1010 is mapped at `0x90000000`; the stub is at `0x9025D700` (= file offset `0x25D700`). Below is the **real-firmware** single-step trace (from `stub_trace.py`):

```asm
0x9025D700  ldr  r0, [pc]      ; literal@0x25D7E8 = 0x902A2EA0 (b1010-internal BSS pointer)
0x9025D704  ldr  r0, [r0]      ; = 0
0x9025D708  cmp  r0, #0
0x9025D70C  blxne r0           ; call only if non-zero (here 0, skipped)
0x9025D710  ldr  r0, [pc]      ; literal = 0x100F48C0
0x9025D714  ldr  r0, [r0]      ; = *(0x100F48C0)
0x9025D718  mov  r1, #0
0x9025D71C  bl   0x9025DA40    ; local init (see 1.1)
0x9025D720  mrc  p15,0,r0,c1,c0,0   ; read SCTLR
0x9025D724  orr  r0, r0, #2    ; enable alignment check (SCTLR.A)
0x9025D728  mcr  p15,0,r0,c1,c0,0   ; write back
0x9025D72C  ldr  r0, [pc]      ; literal = 0x100F48C4
0x9025D730  ldr  r0, [r0]      ; r0 = *(0x100F48C4)
0x9025D734  ldr  r1, [pc]      ; literal = 0x100F48C8
0x9025D738  ldr  r1, [r1]      ; r1 = *(0x100F48C8)
0x9025D73C  mov  r2, #2
0x9025D740  mov  r3, #0
0x9025D744  mov  r4, #1
0x9025D748  ldr  r12, [pc]     ; literal@0x25D7F8 = 0x1002CB8C
0x9025D74C  mov  lr, #0x9025D754   ; return address
0x9025D750  bx   r12           ; → 0x1002CB8C
```

Notes:
- The stub **calls a1010 with arguments**, not a plain jump:
  `func( *(0x100F48C4), *(0x100F48C8), 2, 0, 1 )`, return address `0x9025D754`.
  So `0x1002CB8C` is a **returning init function** inside a1010.
- **Correction to an earlier note**: the literal at `0x25D7E8` is actually `0x902A2EA0` (a b1010-internal BSS pointer), **not** `0x100F48C8` (earlier hand calculation was wrong). The config slots actually read are `0x100F48C0 / 0x100F48C4 / 0x100F48C8`.

### 1.1 About `bl 0x9025DA40` (init)
During measurement we skip it via `--skip-init` (it does not affect the subsequent `bx` target). It is a b1010-internal init unrelated to a1010; to be analyzed separately later.

---

## 2. a1010 load base = `0x10018000` (biggest breakthrough this round)

The `bx` target is fixed at `0x1002CB8C`. Using `stub_trace.py --find-base` to scan page-aligned bases for the one that makes this target land exactly on a **function prologue**, there is a single hit:

```
★ base=0x10018000  foff=0x14B8C  [10 B5 14 20 F9 F7]  Thumb push {...,lr}
```

i.e.:
```
0x1002CB8C − 0x10018000 = 0x14B8C   ← inside a1010 code region 0x14000~0x20000
```

Comparison with the wrong hypotheses:

| base | bx target maps to file | what's there | verdict |
|---|---|---|---|
| `0x10000000` | `0x2CB8C` | data table (every 4-byte group has low halfword `0x0020`; garbage under ARM/Thumb) | ❌ |
| `0x10000040` | `0x2CB4C` | another Thumb function, but entered as ARM | ❌ |
| **`0x10018000`** | **`0x14B8C`** | **clean Thumb function `push{r4,lr}; movs r0,#0x14; bl…`** | ✅ |

> Corroboration: a1010's **157-entry big-endian offset table sits at `0x40–0x2B3`**; entries point to `0x14009 / 0x14063 / …` (`0x14xxx` code region); `0x2CBxx` belongs to the data segment. Only base 0x10018000 puts the bx target back into code.

---

## 3. a1010 entry function `file 0x14B8C` (full disassembly, Thumb-2)

```asm
0x14B8C: B510        push {r4, lr}
0x14B8E: 2014        movs r0, #0x14
0x14B90: F7F9 FFDF   bl   0x0EB52
0x14B94: 2204        movs r2, #4
0x14B96: 2100        movs r1, #0
0x14B98: 200F        movs r0, #0xF
0x14B9A: F7F8 F8DD   bl   0x0CD58        ; init unit #0
0x14B9E: 2204        movs r2, #4
0x14BA0: 2101        movs r1, #1
0x14BA2: 200F        movs r0, #0xF
0x14BA4: F7F8 F8D8   bl   0x0CD58        ; init unit #1
0x14BA8: 2204        movs r2, #4
0x14BAA: 2102        movs r1, #2
0x14BAC: 200F        movs r0, #0xF
0x14BAE: F7F8 FA47   bl   0x0D040        ; init unit #2
0x14BB2: 2201        movs r2, #1
0x14BB4: 2140        movs r1, #0x40
0x14BB6: 2014        movs r0, #0x14
0x14BB8: F7F7 FE32   bl   0x0C820
0x14BBC: 2014        movs r0, #0x14
0x14BBE: F7F9 FEF0   bl   0x0E9A2
0x14BC2: 4996        ldr   r1, [pc,#0x258]  ; = [0x14E1C]
0x14BC4: 4894        ldr   r0, [pc,#0x250]  ; = [0x14E18]
0x14BC6: 6008        str   r0, [r1, #0]
0x14BC8: E8BD 4010   pop.w {r4, lr}          ; return
```

- **Continuous decoding with zero garbage** — the hardest evidence that base / entry / Thumb all line up.
- Semantics: a **config init function** — initializes three units with `r1=0/1/2, r0=0xF (register base), r2=4 (size)`, then two tail calls with `r0=0x14`, then writes `[0x14E18]` into `[0x14E1C]` and returns.
- All `bl` targets (`0x0EB52 / 0x0CD58 / 0x0D040 / 0x0C820 / 0x0E9A2`) fall inside a1010's low-address helper region; self-consistent.

---

## 4. The required "Thumb-bit" fix

- `bx ip` target `0x1002CB8C` has **bit0 = 0 → CPU enters ARM state**;
- but `file 0x14B8C` is **Thumb code**.
- ⇒ must enter Thumb: target should be **`0x1002CB8D`** (bit0=1).

Two options:
- **(A) patch firmware**: change the literal at b1010 file offset `0x25D7F8` from `0x1002CB8C → 0x1002CB8D`, then repack (mind package CRC / `SHA1(body||K8)` integrity).
- **(B) patch QEMU**: don't touch firmware; break at PC == `0x9025D750 (bx ip)`, do `ip |= 1`, and continue.

> Formerly listed as "hypothesis E3", now confirmed by the actual bytes — not optional, mandatory.

---

## 5. config slots `0x100F48C0 / C4 / C8` are outside a1010

```
0x100F48C0 − 0x10018000 = 0xDC8C0
0x100F48C4 − 0x10018000 = 0xDC8C4
0x100F48C8 − 0x10018000 = 0xDC8C8
a1010 size = 0xC0000  → all beyond a1010's end; belong to "next module" or full-flash config area
```

- Without full flash, the stub reads 0 at these three slots and takes a **degenerate "no-callback" path** (`func(0,0,2,0,1)`); hardware is never really initialized → naturally zero MMIO.
- **To do**: fill these three slots with real values from the **next module / full flash**, so the stub takes the real callback path.

---

## 6. Hidden suspect for "0 MMIO" (high confidence, to confirm on hardware)

Found during single-step simulation: if **QEMU unmapped memory returns `0xFF` by default**, then:
```
*(0x100F48C8) = 0xFFFFFFFF → blxne r0 → jumps to 0xFFFFFFFF (bit0=1 even enters Thumb) → dies immediately
```
This is very likely the direct cause of "0 MMIO" at the M1 stage (not missing device models, but the boot stub being led astray).
- Fix: make QEMU unmapped reads return **0**; or provide the real full flash.

---

## 7. Tools (implemented and tested this round)

| File | Purpose |
|---|---|
| `stub_trace.py` | **Zero-dependency** pure-Python boot-stub single-step simulator (ARM-subset interpreter). `--find-base` locates the base, `--skip-init` skips init, `--flash` feeds full flash, `--unmapped` sets the unmapped read value, and it auto-hexdumps entry bytes once `bx` is reached. |
| `d750_m1_analyze.py` | Static analysis quartet: `stub` (literal/branch tracing), `table` (157-entry table endianness), `disasm` (ARM/Thumb × LE/BE), `refs` (reference search), `verdict`. |
| `d750_m1_qemu_snippet.c` | QEMU integration snippet: reset into `0x9025D700`, map a1010 at `0x10018000`, bx-bit fix, config window, trace guidance. |

> During development, 3 bugs were caught and fixed in the simulator: (1) LDR literal missed `PC+8`; (2) `BX/BLX` (`0x012FFF1x`) has bit27-26=00 and was swallowed by the data-processing branch — must be checked first; (3) mask should be `0x0FFFFFF0`. After fixing, both synthetic instructions and real firmware were cross-validated.

---

## 8. Reproduction commands

```powershell
# 1) locate base (expect base=0x10018000, foff=0x14B8C)
python stub_trace.py --find-base --a1010 D750_0115.dec.modules\a1010_011100.bin

# 2) single-step with the real base + dump entry
python stub_trace.py --b1010 D750_0115.dec.modules\b1010_115a.bin `
                     --a1010 D750_0115.dec.modules\a1010_011100.bin --a1010-base 0x10018000

# 3) dual-mode disassembly of the entry
python d750_m1_analyze.py disasm D750_0115.dec.modules\a1010_011100.bin 0x14B8C --base 0x10018000 --n 24
```

---

## 9. QEMU-side change checklist (M1 landing)

1. **Map a1010 at `0x10018000`** (key).
2. Reset **PC=`0x9025D700`**, SVC mode, set SP; stop calling `0x9027D52C` manually.
3. **bx-bit fix**: patch `0x25D7F8` literal to `0x1002CB8D`, or have QEMU trap `0x9025D750` and do `ip|=1`.
4. **config slots**: fill `0x100F48C0/C4/C8` from next module / full flash; make unmapped reads return 0.
5. Observe: `-d in_asm,exec,cpu,int -D qemu.log`, confirm PC reliably enters `0x1002CB8D` and runs continuously inside a1010.

---

## 10. TODO / discussion

- [ ] Apply §9 to QEMU and run, produce `qemu.log`: confirm real entry into `0x1002CB8D` (Thumb) and continuous execution in a1010 → **M1 done**.
- [ ] Disassemble `0x9025DA40` (b1010 init) and the entry function's helpers (`0x0EB52 / 0x0CD58 / 0x0D040 / 0x0C820 / 0x0E9A2`).
- [ ] Pin down a1010's flash load offset (= `0x18000`?) and the **next module** (where the config slots live); obtain full flash / module offset table.
- [ ] First post-a1010 MMIO access address (M1 acceptance point) → basis for M2 device modeling.

---

*Note: every address/byte here comes from D750_0115.bin measurements, not assumptions. If it differs from your local result, trust `stub_trace.py --find-base` output and attach it in the issue.*
