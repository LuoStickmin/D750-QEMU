import sys, struct

d = open(sys.argv[1], "rb").read()

for v in [0x2CB8C, 0x2CB4C, 0x14009, 0xC2D1]:
    pat = struct.pack(">I", v)
    hits, i = [], 0
    while True:
        j = d.find(pat, i)
        if j < 0:
            break
        hits.append(j)
        i = j + 1
    print("value 0x%X -> file offsets %s" % (v, [hex(x) for x in hits[:20]]))

# 估算表在什么位置结束
n = 0
for off in range(0x40, len(d), 4):
    v = struct.unpack_from(">I", d, off)[0]
    if v == 0 or v >= len(d):
        break
    n += 1
print("table entries before break: %d, ends at 0x%X" % (n, 0x40 + n * 4))
